This sketch should be uploaded in another Arduino or Atmega 328/pu 
NOT IN HOST COMPUTER's ARDUINO.